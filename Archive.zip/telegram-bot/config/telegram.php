<?php

return [
    'bot_token' => env('TELEGRAM_BOT_API_TOKEN'),
    'bot_name' => env('TELEGRAM_BOT_NAME'),
    'bot_username' => env('TELEGRAM_BOT_USERNAME'),
    'bot_admin_chat_id' => env('TELEGRAM_ADMIN_CHAT_ID'),
    'bot_link' => env('TELEGRAM_BOT_LINK'),
];