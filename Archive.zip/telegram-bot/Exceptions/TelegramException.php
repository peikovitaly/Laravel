<?php

declare(strict_types=1);

namespace Telegram\Bot\Exceptions;

use RuntimeException;

class TelegramException extends RuntimeException
{
}
